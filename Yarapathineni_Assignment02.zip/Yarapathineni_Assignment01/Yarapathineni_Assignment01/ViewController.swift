//
//  ViewController.swift
//  Yarapathineni_Assignment01
//
//  Created by Yarapathineni,Sai Tejaswini on 2/1/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var firstNameOutlet: UITextField!
    
    @IBOutlet weak var lastNameOutlet: UITextField!
    
    @IBOutlet weak var yearOutlet: UITextField!
    
    @IBOutlet weak var detailsLabel: UILabel!
    
    @IBOutlet weak var fullNameLabel: UILabel!
    
    @IBOutlet weak var initialsLabel: UILabel!
    
    @IBOutlet weak var ageLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func SubmitBTN(_ sender: Any) {
        var fname =  firstNameOutlet.text!
        var lname = lastNameOutlet.text!
        var year = yearOutlet.text!
        let pyear = Calendar.current.component(.year, from: Date())
        let age = pyear - (Int(year) ?? 0)
        detailsLabel.text="Details"
        fullNameLabel.text="Full Name : \(lname) \(fname)"
        initialsLabel.text = "Initials : \(lname.first!) \(fname.first!)"
        ageLabel.text="Age :  \(age)"
    }
    
    @IBAction func ResetBTN(_ sender: Any) {
        
        firstNameOutlet.text=""
        lastNameOutlet.text=""
        yearOutlet.text=""
        detailsLabel.text=""
        fullNameLabel.text=""
        initialsLabel.text=""
        ageLabel.text=""
    }
}

