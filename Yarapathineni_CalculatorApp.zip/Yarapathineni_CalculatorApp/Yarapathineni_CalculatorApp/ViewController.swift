//
//  ViewController.swift
//  Yarapathineni_CalculatorApp
//
//  Created by Yarapathineni,Sai Tejaswini on 2/16/23.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        resultOutlet.text = "0"
        // Do any additional setup after loading the view.
        
    }
    var v1:Double = 0
    var v2:Double = 0
    var option:String = ""
    
    
    @IBOutlet weak var resultOutlet: UILabel!
    
    @IBAction func ButtonAC(_ sender: Any) {
        resultOutlet.text = ""
        v1 = 0.0
        v2 = 0.0
        option = ""
    }
    
    @IBAction func ButtonC(_ sender: Any) {
        var value = resultOutlet.text!
        if(!value.isEmpty){
            value.removeLast()
        }
        if(value.isEmpty){
            v1 = -9.99
            v2 = -9.99
            
        }
        resultOutlet.text = value
    }
    
    
    @IBAction func ButtonVariation(_ sender: Any) {
        if(Int(resultOutlet.text!)! > 0 )
        {
            resultOutlet.text = "-"+resultOutlet.text!
        }
        else
        {
            let st: String = resultOutlet.text!
            resultOutlet.text = String(st[st.index(after: st.startIndex) ..< st.endIndex])
        }
    }
    
    @IBAction func ButtonAdd(_ sender: Any) {
        option = "÷"
        v1 = Double(resultOutlet.text!)!
        resultOutlet.text = ""
        
    }
    
    @IBAction func Button7(_ sender: Any) {
        valueChange(t: "7")
    }
    
    @IBAction func Button8(_ sender: Any) {
        valueChange(t: "8")
    }
    
    @IBAction func Button9(_ sender: Any) {
        valueChange(t: "9")
    }
    
    @IBAction func ButtonMultiply(_ sender: Any) {
        option = "×"
        v1 = Double(resultOutlet.text!)!
        resultOutlet.text = ""
    }
    @IBAction func Button4(_ sender: Any) {
        valueChange(t: "4")
    }
    
    @IBAction func Button5(_ sender: Any) {
        valueChange(t: "5")
    }
    
    @IBAction func Button6(_ sender: Any) {
        valueChange(t: "6")
    }
    
    @IBAction func ButtonMinus(_ sender: Any) {
        option = "-"
        v1 = Double(resultOutlet.text!)!
        resultOutlet.text = ""
    }
    
    @IBAction func Button1(_ sender: Any) {
        valueChange(t: "1")
    }
    
    @IBAction func Button2(_ sender: Any) {
        valueChange(t: "2")
    }
    
    @IBAction func Button3(_ sender: Any) {
        valueChange(t: "3")
    }
    
    @IBAction func ButtonPlus(_ sender: Any) {
        option = "+"
        v1 = Double(resultOutlet.text!)!
        resultOutlet.text = ""
    }
    
    @IBAction func Button0(_ sender: Any) {
        valueChange(t: "0")
    }
    
    @IBAction func ButtonDot(_ sender: Any) {
        valueChange(t: ".")
    }
    
    
    @IBAction func ButtonMod(_ sender: Any) {
        option = "%"
        v1 = Double(resultOutlet.text!)!
        resultOutlet.text = ""
    }
    
    @IBAction func ButtonEqual(_ sender: Any) {
        
        v2 = Double(resultOutlet.text!)!
        switch option{
        case "+":
            Result(val1: v1+v2)
        case "-":
            Result(val1: v1-v2)
        case "÷":
            if(v2 == 0)
            {
                resultOutlet.text = "Not a number"
            }
            else{
                Result(val1: v1/v2)
                
            }
        case "×":
            Result(val1: v1*v2)
        case "%":
                var out = v1.truncatingRemainder(dividingBy: v2)
                resultOutlet.text = String(round(out*100.0)/100.0)
        default:
            print("")
            
        }
    }
    
    func valueChange(t:String){
        if(resultOutlet.text! == "0"){
            resultOutlet.text = t
        }
        else{
            resultOutlet.text = resultOutlet.text! + t
        }
    }
    
    func Result(val1: Double)
    {
        if(val1.truncatingRemainder(dividingBy: 1) == 0.0)
        {
            resultOutlet.text = String(Int(val1))
        }
        else{
            
            resultOutlet.text = String(round(val1*100000.0)/100000.0)
        }
    }

}


